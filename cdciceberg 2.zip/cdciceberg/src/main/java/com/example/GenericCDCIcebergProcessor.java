package com.example;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.JsonNode;
import org.apache.spark.sql.*;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.streaming.Trigger;
import org.apache.spark.sql.types.*;
import static org.apache.spark.sql.functions.*;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeoutException;
import java.util.*;

public class GenericCDCIcebergProcessor {
    private final ConfigurationManager config;
    private final String warehousePath;
    private final String checkpointPath;

    public GenericCDCIcebergProcessor(String configPath) throws IOException {
        this.config = new ConfigurationManager(configPath);
        // Create absolute paths for warehouse and checkpoints
        File currentDir = new File(System.getProperty("user.dir"));
        File warehouseDir = new File(currentDir, "warehouse");
        File checkpointDir = new File(currentDir, "checkpoints");

        // Create directories
        if (!warehouseDir.exists() && !warehouseDir.mkdirs()) {
            throw new RuntimeException("Failed to create warehouse directory: " + warehouseDir.getAbsolutePath());
        }
        if (!checkpointDir.exists() && !checkpointDir.mkdirs()) {
            throw new RuntimeException("Failed to create checkpoint directory: " + checkpointDir.getAbsolutePath());
        }

        this.warehousePath = warehouseDir.getAbsolutePath();
        this.checkpointPath = checkpointDir.getAbsolutePath();

        System.out.println("Warehouse path: " + warehousePath);
        System.out.println("Checkpoint path: " + checkpointPath);
    }

    public void process() {
        final SparkSession spark = createSparkSession(warehousePath);
        StreamingQuery query = null;

        try {
            spark.sparkContext().setLogLevel("ERROR");

            // Create namespace and table
            String namespace = config.getNamespace();
            spark.sql("CREATE NAMESPACE IF NOT EXISTS " + namespace);
            createIcebergTableIfNotExists(spark);

            // Read from Kafka with configuration
            Dataset<Row> cdcEvents = spark
                    .readStream()
                    .format("kafka")
                    .options(config.getKafkaOptions())
                    .load()
                    .select(from_json(col("value").cast("string"), config.getCDCSchema()).as("data"))
                    .select("data.*");

            // Process stream with micro-batch optimization
            query = processCDCEvents(cdcEvents, spark, checkpointPath);

            // Add shutdown hook
            final StreamingQuery finalQuery = query;
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                try {
                    if (finalQuery != null && finalQuery.isActive()) {
                        finalQuery.stop();
                    }
                } catch (Exception e) {
                    System.err.println("Error during shutdown: " + e.getMessage());
                }
            }));

            // Monitor the streaming query
            monitorStreamingQuery(query);
            System.out.println("\n=== Final Table State ===");
            verifyIcebergTable(spark);
            exploreDataFiles(warehousePath);
            showTableData(spark);

        } catch (Exception e) {
            System.err.println("Error: " + e.getMessage());
            e.printStackTrace();
        } finally {
            cleanupResources(query, spark);
        }
    }

    private static void monitorStreamingQuery(StreamingQuery query) {
        while (query != null && query.isActive()) {
            try {
                Thread.sleep(1000);  // Sleep for 1 second between checks
                System.out.println("Query is active: " + query.status().message());
            } catch (InterruptedException e) {
                Thread.currentThread().interrupt();
                System.err.println("Monitoring interrupted: " + e.getMessage());
                break;
            }
        }
    }

    private SparkSession createSparkSession(String warehousePath) {
        return SparkSession
                .builder()
                .appName("CDC-Iceberg-Processor")
                .master("local[*]")
                .config("spark.sql.extensions", "org.apache.iceberg.spark.extensions.IcebergSparkSessionExtensions")
                .config("spark.sql.catalog.local", "org.apache.iceberg.spark.SparkCatalog")
                .config("spark.sql.catalog.local.type", "hadoop")
                .config("spark.sql.catalog.local.warehouse", warehousePath)
                .config("spark.sql.defaultCatalog", "local")
                .config("spark.sql.warehouse.dir", warehousePath)
                .config("spark.jars.packages", "org.apache.spark:spark-sql-kafka-0-10_2.12:3.5.0")
                .config("spark.driver.memory", "4g")
                .config("spark.executor.memory", "4g")
                .config("spark.memory.offHeap.enabled", "true")
                .config("spark.memory.offHeap.size", "2g")
                .config("spark.driver.maxResultSize", "2g")
                .config("spark.default.parallelism", "4")
                .config("spark.sql.shuffle.partitions", "4")
                .config("spark.driver.extraJavaOptions", "-Xss8m")
                .config("spark.executor.extraJavaOptions", "-Xss8m")
                .config("spark.sql.adaptive.enabled", "false")
                // Updated Kryo configuration
                .config("spark.serializer", "org.apache.spark.serializer.KryoSerializer")
                .config("spark.kryo.registrationRequired", "false")
                .config("spark.kryoserializer.buffer", "256k")
                .config("spark.kryoserializer.buffer.max", "512m")
                // Network configurations
                .config("spark.hadoop.fs.defaultFS", "file:///")
                .config("spark.driver.host", "localhost")
                .config("spark.driver.bindAddress", "127.0.0.1")
                .getOrCreate();
    }

    private static void cleanupResources(StreamingQuery query, SparkSession spark) {
        try {
            if (query != null && query.isActive()) {
                query.stop();
                // Wait for the query to stop
                long timeout = System.currentTimeMillis() + 10000; // 10 seconds timeout
                while (query.isActive() && System.currentTimeMillis() < timeout) {
                    try {
                        Thread.sleep(100);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        break;
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("Error stopping query: " + e.getMessage());
        } finally {
            if (spark != null) {
                spark.close();
            }
        }
    }

    private StreamingQuery processCDCEvents(Dataset<Row> cdcEvents, SparkSession spark, String checkpointPath) throws StreamingQueryException {
        try {
            return cdcEvents
                    .writeStream()
                    .foreachBatch((Dataset<Row> batch, Long batchId) -> {
                        if (!batch.isEmpty()) {
                            try {
                                // Handle deletes
                                Dataset<Row> deleteBatch = batch.filter(col(config.getDeleteFlagColumn())
                                        .equalTo(config.getDeleteFlagValue()));
                                if (!deleteBatch.isEmpty()) {
                                    // Get IDs to delete
                                    String deleteIds = deleteBatch.select(config.getPrimaryKeyColumn())
                                            .collectAsList()
                                            .stream()
                                            .map(row -> row.get(0).toString())
                                            .collect(java.util.stream.Collectors.joining(","));

                                    if (!deleteIds.isEmpty()) {
                                        spark.sql(String.format("DELETE FROM %s WHERE %s IN (%s)",
                                                config.getFullTableName(),
                                                config.getPrimaryKeyColumn(),
                                                deleteIds));
                                    }
                                }

                                // Handle updates and inserts
                                Dataset<Row> upsertBatch = batch.filter(
                                        col(config.getDeleteFlagColumn()).notEqual(config.getDeleteFlagValue())
                                                .or(col(config.getDeleteFlagColumn()).isNull()));

                                if (!upsertBatch.isEmpty()) {
                                    // Select only the columns that exist in the target table
                                    Dataset<Row> filteredBatch = upsertBatch.select(
                                            config.getTargetColumns().toArray(new String[0]));

                                    filteredBatch.createOrReplaceTempView("updates");

                                    // Execute MERGE
                                    String mergeSql = buildMergeSql();
                                    spark.sql(mergeSql);
                                    spark.catalog().dropTempView("updates");
                                }

                                // Log progress
                                System.out.println("Processed batch " + batchId + " with " + batch.count() + " records");
                                if (config.isDebugMode()) {
                                    System.out.println("\n=== Verifying Changes ===");
                                    verifyIcebergTable(spark);
                                    exploreDataFiles(warehousePath);
                                    showTableData(spark);
                                }

                            } catch (Exception e) {
                                System.err.println("Error processing batch " + batchId + ": " + e.getMessage());
                                e.printStackTrace();
                            }
                        }
                    })
                    .option("checkpointLocation", checkpointPath + "/query")
                    .trigger(Trigger.ProcessingTime(config.getTriggerInterval()))
                    .start();
        } catch (TimeoutException e) {
            throw new RuntimeException(e);
        }
    }

    private String buildMergeSql() {
        List<String> updateColumns = config.getTargetColumns().stream()
                .filter(col -> !col.equals(config.getPrimaryKeyColumn()))
                .collect(java.util.stream.Collectors.toList());

        String updateSet = updateColumns.stream()
                .map(col -> String.format("t.%s = s.%s", col, col))
                .collect(java.util.stream.Collectors.joining(", "));

        return String.format(
                "MERGE INTO %s t " +
                        "USING (SELECT %s FROM updates) s " +
                        "ON t.%s = s.%s " +
                        "WHEN MATCHED THEN UPDATE SET %s " +
                        "WHEN NOT MATCHED THEN INSERT * ",
                config.getFullTableName(),
                String.join(", ", config.getTargetColumns()),
                config.getPrimaryKeyColumn(),
                config.getPrimaryKeyColumn(),
                updateSet
        );
    }

    private void createIcebergTableIfNotExists(SparkSession spark) {
        StringBuilder createTableSQL = new StringBuilder()
                .append(String.format("CREATE TABLE IF NOT EXISTS %s (\n", config.getFullTableName()));

        // Add columns from schema
        List<String> columnDefs = new ArrayList<>();
        config.getTableSchema().fields().forEach(field ->
                columnDefs.add(String.format("  %s %s", field.name(), sparkTypeToSQL(field.dataType()))));

        createTableSQL.append(String.join(",\n", columnDefs));
        createTableSQL.append("\n) USING iceberg\n")
                .append("TBLPROPERTIES (\n")
                .append("  'write.merge.mode'='merge-on-read',\n")
                .append("  'write.update.mode'='merge-on-read',\n")
                .append("  'write.delete.mode'='merge-on-read',\n")
                .append("  'format-version'='2',\n")
                .append("  'write.distribution-mode'='none',\n")
                .append("  'write.update.isolation-level'='snapshot'\n")
                .append(")");

        spark.sql(createTableSQL.toString());
    }

    private String sparkTypeToSQL(DataType dataType) {
        if (dataType instanceof StringType) return "STRING";
        if (dataType instanceof LongType) return "BIGINT";
        if (dataType instanceof IntegerType) return "INT";
        if (dataType instanceof BooleanType) return "BOOLEAN";
        if (dataType instanceof DoubleType) return "DOUBLE";
        if (dataType instanceof TimestampType) return "TIMESTAMP";
        return "STRING"; // Default to STRING for unknown types
    }

    private static void showTableData(SparkSession spark) {
        try {
            System.out.println("\n============== ICEBERG TABLE DATA ANALYSIS ==============");

            // Current Data
            System.out.println("\n1. Current Table Data:");
            spark.sql("SELECT * FROM local.db.test_cdc_table ORDER BY id").show(false);

            // Table History
            System.out.println("\n2. Table Modification History:");
            spark.sql("SELECT * FROM local.db.test_cdc_table.history").show(false);

            // Get snapshots and show them
            System.out.println("\n3. Available Snapshots:");
            Dataset<Row> snapshots = spark.sql("SELECT * FROM local.db.test_cdc_table.snapshots ORDER BY committed_at");
            snapshots.show(false);

            // Time Travel Examples
            System.out.println("\n4. Time Travel Queries for Last Few Snapshots:");
            snapshots.select("snapshot_id", "committed_at")
                    .limit(3)
                    .collectAsList()
                    .forEach(row -> {
                        String snapshotId = row.get(0).toString();
                        String timestamp = row.get(1).toString();
                        System.out.println("\nData at Snapshot " + snapshotId + " (Time: " + timestamp + ")");
                        try {
                            spark.sql("SELECT * FROM local.db.test_cdc_table VERSION AS OF " + snapshotId + " ORDER BY id")
                                    .show(false);
                        } catch (Exception e) {
                            System.err.println("Error querying snapshot " + snapshotId + ": " + e.getMessage());
                        }
                    });

            // Show recent changes
            System.out.println("\n5. Recent Changes in Table:");
            spark.sql("SELECT * FROM local.db.test_cdc_table.changes").show(false);

        } catch (Exception e) {
            System.err.println("Error querying table data: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void verifyIcebergTable(SparkSession spark) {
        try {
            // Get current data
            Dataset<Row> currentData = spark.sql("SELECT * FROM local.db.test_cdc_table");
            System.out.println("\n=== Current Table Data ===");
            System.out.println("Total Records: " + currentData.count());
            System.out.println("Schema: ");
            currentData.printSchema();
            System.out.println("\nSample Data:");
            currentData.show(5, false);

            // Get Iceberg metadata
            System.out.println("\n=== Iceberg Table History ===");
            spark.sql("SELECT * FROM local.db.test_cdc_table.history").show(5, false);

            // Show snapshots
            System.out.println("\n=== Iceberg Table Snapshots ===");
            spark.sql("SELECT * FROM local.db.test_cdc_table.snapshots").show(5, false);

        } catch (Exception e) {
            System.err.println("Error verifying table: " + e.getMessage());
            e.printStackTrace();
        }
    }

    private static void exploreDataFiles(String warehousePath) {
        File warehouseDir = new File(warehousePath);
        System.out.println("\n=== Exploring Data Files ===");
        System.out.println("Warehouse root: " + warehousePath);
        listDirectory(warehouseDir, 0);
    }
    private static void listDirectory(File dir, int level) {
        String indent = "  ".repeat(level);
        File[] files = dir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.isDirectory()) {
                    System.out.println(indent + "📁 " + file.getName());
                    listDirectory(file, level + 1);
                } else {
                    System.out.println(indent + "📄 " + file.getName() + " (" + file.length() + " bytes)");
                }
            }
        }
    }
}
